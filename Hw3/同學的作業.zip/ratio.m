function [r,ii]=ratio(x,d)
    r=inf;
    for i=1:length(x)
       if x(i)/d(i)<r && d(i) >0
           r=x(i)/d(i);
           ii=i;
       end
    end
end