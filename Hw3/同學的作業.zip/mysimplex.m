function [xx, cc] = mysimplex(c, A, b, x0)
    [~,bb]=size(A);
    bN=1:length(x0);
    bB=length(x0)+1:bb;
    x=[x0;b];
    if ~all(A*x<=b) || ~all(x0>=0) xx=x0; cc=2; return;    end
    %i=0;
    while 1
    %i=i+1;
    %disp(['Round:' num2str(i)]);
    B=A(:,bB);    N=A(:,bN);
    xB=x(bB);     xN=x(bN);
    cB=c(bB);     cN=c(bN);
    s=cN-N'*(B'\cB);
    if all(s>=0)        cc=0;   xx=x(1:2);  return;    end
    iq=find(s<0);
    rng('shuffle');
    iq=iq(randi(length(iq)));
    q=bN(iq);
    d=B\A(:,q);
    if all(d<=0)        cc=1;   xx=x(1:2);  return;    end
    [r,ip]=ratio(xB,d);
    
    e=zeros(length(bN),1);    e(iq)=1;
    
    x([bB';bN'])=[xB;xN]+r*[-d;e]
    p=bB(ip);
    bB=union(setdiff(bB,p),q);
    bN=union(setdiff(bN,q),p);
    end
end
