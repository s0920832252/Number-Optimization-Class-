function [ xK, lambdaK, sK, result ] = IPM( A, b, c, x0, lambda0, s0 )
%IPL Summary of this function goes here
%   Detailed explanation goes here

gamma = 0.001;
lambdaK = lambda0;
m = size(A,1);
n = size(A,2);
sigmaK = 0.1;
sK = s0;
xK = x0;
muK = lambdaK' * sK / m;
e = ones(m,1);
alphaK = 1;
while( muK ~= 0 )
    deltaK = [zeros(n) -A' zeros(n,m) ; -A zeros(m) eye(m) ; zeros(m,n) diag(sK) diag(lambdaK)] \ [(A' * lambdaK - c) ; (A * xK - sK - b) ; (sigmaK * muK * e - diag(lambdaK) * diag(sK) * e)]
    
    deltaxK = deltaK(1:n,1);
    deltalambdaK = deltaK(n+1:m+n,1);
    deltasK = deltaK(m+n+1:2*m+n,1);
    check = min((lambdaK + alphaK * deltalambdaK) .* (sK + alphaK * deltasK));
    while(check < gamma * muK)
        alphaK = alphaK / 2;
        check = min((lambdaK + alphaK * deltalambdaK) .* (sK + alphaK * deltasK));
    end
    
    xK = xK + alphaK * deltaxK;
    lambdaK = lambdaK + alphaK * deltalambdaK;
    sK = sK + alphaK * deltasK;
    muK = lambdaK' * sK / m;
end
result = c' * xK;
end
