function [x,l,s,t] = IPM(A,b,c,x0,l0,s0)
    x = x0;
    l = l0;
    s = s0;
    [m,n] = size(A);
    pa = 0.4;
    all = [x;l;s];
    a = 20;
    t = 0 ;
    while (1)
         t = t+1;
         u = (l'*s)/m;
         if(u<1)
             break;
         end
         H = [zeros(n,n),-A',zeros(n,m);-A,zeros(m,m),eye(m);zeros(m,n),diag(s),diag(l)];
         g = [A'*l-c;A*x-s-b;pa*u*ones(m,1)-diag(l)*diag(s)*ones(m,1)];
         dall = H\g;
         
         while(1)
              tmp = all + a*dall;
              mini = min( tmp(n+1:n+m).*tmp(n+m+1:n+2*m) );
           
              if( mini >= 0.001*u)
                  break;
              end
              a = a/2;
         end
         all = tmp;
         x = all(1:n);
         l = all(n+1:n+m);
         s = all(n+m+1:n+2*m);
    end
end